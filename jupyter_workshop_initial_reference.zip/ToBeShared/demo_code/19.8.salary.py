from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

data_raw = pd.read_csv("data/Predict-The-Data-Scientists-Salary-In-India_Train_Dataset.csv")
data = data_raw.loc[:,['company_name_encoded','experience', 'location', 'salary']]

#Splitting the experience column into two numerical columns of minimum experience and maximum experience.
exp = data['experience'].str.replace("yrs","").str.strip().str.split("-",expand=True)
#or 
#apply for Series(fn takes each element) ,or fn takes an ufunc 
#applymap:DF (fn takes each element)
#apply: DF(fn = ufunc takes full Series/columns)
#DataFrame.transform(func, *args, **kwargs), func(each_column):new_column
exp_min = data['experience'].apply(lambda s: s.replace("yrs","").strip().split("-")[0])
exp_max = data['experience'].apply(lambda s: s.replace("yrs","").strip().split("-")[1])
data["minimum_exp"] = exp.iloc[:,0]
data["maximum_exp"] = exp.iloc[:,1]

#location and salary columns are categorical 
loc_encoder = LabelEncoder().fit(data['location'])
sal_encoder = LabelEncoder().fit(data['salary'])
data['location'] = loc_encoder.transform(data['location'])
y = sal_encoder.transform(data['salary'])

data.drop(['experience','salary'], inplace = True, axis = 1)
#data = data[['company_name_encoded', 'location','minimum_exp', 'maximum_exp']]


sc = StandardScaler()
data.loc[:,['company_name_encoded', 'minimum_exp', 'maximum_exp','location']] = sc.fit_transform(data[['company_name_encoded', 'minimum_exp', 'maximum_exp', 'location']])

X_train,  X_val, y_train, y_val  = train_test_split(data.values, y, test_size = 0.2, random_state = 21)

# classifier = MLPClassifier(hidden_layer_sizes=(256,128,64,32,16,8), max_iter=500,activation = 'relu',solver='adam',random_state=1)
# classifier.fit(X_train, y_train)
# 
# #hidden_layer_sizes : This parameter allows us to set the number of layers and the number of nodes 
# #Each element in the tuple represents the number of nodes at the ith position 
# #where i is the index of the tuple.
# #Thus the length of tuple denotes the total number of hidden layers in the network.
# #max_iter: It denotes the number of epochs.
# #activation: The activation function for the hidden layers.activation{'identity', 'logistic', 'tanh', 'relu'}, default='relu'
# #solver: This parameter specifies the algorithm for weight optimization across the nodes.solver{'lbfgs', 'sgd', 'adam'}, default='adam'
# #random_state: The parameter allows to set a seed for reproducing the same results
# #learning_rate{'constant', 'invscaling', 'adaptive'}, default='constant'
# 
# classifier.score(X_train, y_train)
# y_pred = classifier.predict(X_val)
# print("confusion matrix from MLP:", confusion_matrix( y_val,y_pred))
# 
# #Printing the accuracy
# print("f1 score from MLP:", f1_score(y_val, y_pred, average='weighted'))

CV= KFold(n_splits=5,shuffle=True)

clf1 = DecisionTreeClassifier()
clf2 = RandomForestClassifier(n_estimators=100)
clf3 = ExtraTreesClassifier(n_estimators=100)
clf4 =  AdaBoostClassifier(n_estimators=100)
clf5 =  GradientBoostingClassifier(n_estimators=100)
pipe = Pipeline([('reg', clf1)])

grid = dict(
 reg=[clf1,clf2, clf3, clf4, clf5], 
)
#grid = dict(
# reg=[clf5], 
#)

search = GridSearchCV(pipe, grid)
search.fit(X_train,y_train)
print("best Estimator:", search.best_estimator_)

#print(search.score(X_train, y_train))
#print(search.score(X_val, y_val))
y_pred = search.predict(X_val)
print("confusion matrix from Best estimator:", confusion_matrix( y_val,y_pred))

#Printing the accuracy
print("f1 score from Best estimator:", f1_score(y_val, y_pred, average='weighted'))