import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 


fig, ((ax1,ax2),(ax3,ax4)) = plt.subplots(2, 2)


x = np.linspace(0,100,100)
y = np.random.normal(size=(100,))
ax1.plot(x,y, 'b-') # blue line plot 
ax1.axhline(np.mean(y), linestyle='--', color='.5')
#x cordinate, y1 cordinate, y2 cordinate 
ax1.fill_between(x, np.mean(y)+np.std(y),np.mean(y) - np.std(y),  color='r', alpha=.2)
ax1.set_ylabel('Values')
ax1.set_xlabel('Numbers')

from scipy.stats import * 
#Density (.pdf)				Returns probability Pr of a random variable X, ie Pr(x), 
#Distribution (.cdf)  		Returns cummulative Pr ie Pr(x <= q) or Pr(x >=q) with lower.tail = FALSE
#Quantile (.ppf)			Inverse of cdf, Given Probability p, returns x, value of X ie what is the value of x given p
#Random generation(.rvs)	Generates n random number based on this distribution 

#Display the probability density function (pdf):
loc=0
scale=1
x = np.linspace(norm.ppf(0.01,loc=loc, scale=scale), norm.ppf(0.99,loc=loc, scale=scale), 100)
ax2.plot(x, norm.pdf(x,loc=loc, scale=scale),'r-', lw=5, alpha=0.6, label='norm pdf')
#Generate random numbers:
r = norm.rvs(size=1000,loc=loc, scale=scale)
#And compare the histogram:
ax2.hist(r,  density=True, histtype='stepfilled', alpha=0.2)
ax2.set_xlabel('pdf')

#Sum of two Gaussian 
df = pd.DataFrame({'A': norm.rvs(size=1000,loc=0, scale=1),
                   'B': norm.rvs(size=1000,loc=3, scale=2),
                   'C': np.random.rand(1000,1).squeeze(),
                   'D': binom.rvs(size=1000, n=1000, p=0.4)/1000
                   })

df['A+B'] = df.A + df.B
df['All'] = df.A + df.B +df.C+df.D

str1= "norm+norm(mu=%2.1f, sd=%2.1f)" % (df['A+B'].mean(), df['A+B'].std())
str2= "+ many pdf(mu=%2.1f, sd=%2.1f)" % (df['All'].mean(), df['All'].std())

#from pandas.plotting import scatter_matrix
#scatter_matrix(df, alpha=0.2, diagonal='kde')

df['A+B'].plot(kind='kde', ax=ax3)
ax3.set_xlabel(str1)
df['All'].plot(kind='kde', ax=ax4)
ax4.set_xlabel(str2)

plt.show()