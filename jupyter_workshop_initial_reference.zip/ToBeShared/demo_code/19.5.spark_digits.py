from __future__ import print_function, division
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
from pyspark import *                   #SparkContext,RDD,Broadcast,Accumulator,SparkConf,SparkFiles,StorageLevel,TaskContext

from pyspark.sql import *               #SparkSession, DataFrame, Column, Row, GroupedData, DataFrameNaFunctions, DataFrameStatFunctions, Window
import pyspark.sql.functions as F
from pyspark.sql.types import * 

from pyspark.ml  import *               #Transformer, UnaryTransformer,Estimator,Model,Pipeline,PipelineModel
from pyspark.ml.feature import *        #Binarizer, BucketedRandomProjectionLSHE, BucketedRandomProjectionLSHModelE, Bucketizer, ChiSqSelectorE, ChiSqSelectorModelE, CountVectorizer, CountVectorizerModel, DCT, ElementwiseProduct, FeatureHasherE, HashingTF, IDF, IDFModel, ImputerE, ImputerModelE, IndexToString, MaxAbsScaler, MaxAbsScalerModel, MinHashLSHE, MinHashLSHModelE, MinMaxScaler, MinMaxScalerModel, NGram, Normalizer, OneHotEncoderD, OneHotEncoderEstimator, OneHotEncoderModel, PCA, PCAModel, PolynomialExpansion, QuantileDiscretizerE, RegexTokenizer, RFormulaE, RFormulaModelE, SQLTransformer, StandardScaler, StandardScalerModel, StopWordsRemover, StringIndexer, StringIndexerModel, Tokenizer, VectorAssembler, VectorIndexer, VectorIndexerModel, VectorSizeHintE, VectorSlicer, Word2Vec, Word2VecModel, , 
from pyspark.ml.classification import * #LinearSVCE, LinearSVCModelE, LogisticRegression, LogisticRegressionModel, LogisticRegressionSummaryE, LogisticRegressionTrainingSummaryE, BinaryLogisticRegressionSummaryE, BinaryLogisticRegressionTrainingSummaryE, DecisionTreeClassifier, DecisionTreeClassificationModel, GBTClassifier, GBTClassificationModel, RandomForestClassifier, RandomForestClassificationModel, NaiveBayes, NaiveBayesModel, MultilayerPerceptronClassifier, MultilayerPerceptronClassificationModel, OneVsRestE, OneVsRestModelE, , 
from pyspark.ml.clustering import *     #BisectingKMeans, BisectingKMeansModel, BisectingKMeansSummaryE, KMeans, KMeansModel, GaussianMixture, GaussianMixtureModel, GaussianMixtureSummaryE, LDA, LDAModel, LocalLDAModel, DistributedLDAModel, , 
from pyspark.ml.linalg import *         #Vector, DenseVector, SparseVector, Vectors, Matrix, DenseMatrix, SparseMatrix, Matrices, , 
from pyspark.ml.recommendation import * #ALS, ALSModel, , 
from pyspark.ml.regression import *     #AFTSurvivalRegressionE, AFTSurvivalRegressionModelE, DecisionTreeRegressor, DecisionTreeRegressionModel, GBTRegressor, GBTRegressionModel, GeneralizedLinearRegressionE, GeneralizedLinearRegressionModelE, GeneralizedLinearRegressionSummaryE, GeneralizedLinearRegressionTrainingSummaryE, IsotonicRegression, IsotonicRegressionModel, LinearRegression, LinearRegressionModel, LinearRegressionSummaryE, LinearRegressionTrainingSummaryE, RandomForestRegressor, RandomForestRegressionModel, , 
from pyspark.ml.stat import *           #moduleChiSquareTestE, CorrelationE, , 
from pyspark.ml.tuning import *         #ParamGridBuilder, CrossValidator, CrossValidatorModel, TrainValidationSplitE, TrainValidationSplitModelE, , 
from pyspark.ml.evaluation import *     #Evaluator, BinaryClassificationEvaluatorE, RegressionEvaluatorE, MulticlassClassificationEvaluatorE, ClusteringEvaluatorE, , 
from pyspark.ml.fpm import *            #FPGrowthE, FPGrowthModelE, , 
from pyspark.ml.util import *           #BaseReadWrite, DefaultParamsReadable, DefaultParamsReader, DefaultParamsWritable, DefaultParamsWriter, Identifiable, JavaMLReadable, JavaMLReader, JavaMLWritable, JavaMLWriter, JavaPredictionModel, MLReadable, MLReader, MLWritable, MLWriter, , , 



from sklearn.datasets import *  

digits = load_digits()
#print((digits.data.min(), digits.data.max()))
#print(digits.data.shape)
#(0.0, 16.0)
#(1797, 64)

#In the matrix X, each row contains 8*8=64 pixels (in grayscale, values between 0 and 16). 
#The row-major ordering is used.
feature_names = [str(i) for i in range(digits.data.shape[1])]
pdf = pd.DataFrame(digits.data, columns=feature_names)
pdf['label'] = digits.target

spark = SparkSession.builder.appName("basic").getOrCreate()
df = spark.createDataFrame(pdf)

assembler = VectorAssembler().setInputCols(feature_names).setOutputCol("features")

# If label contains string category or number category, this transforms to [0,numlabels)
#In our case target is already processed 
#Note this is Transformer, hence call .fit to get values to use in labelIndexer.labels
#labelIndexer = StringIndexer(inputCol="Name", outputCol="indexedLabel").fit(df)
# Automatically identify categorical features, and index them.
# Set maxCategories so features with > 4 distinct values are treated as continuous.
#featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)
#rf = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures", numTrees=10)
#Convert indexed labels back to original labels.
#labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel",  labels=labelIndexer.labels)
#pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf, labelConverter])




trainingData, testData = df.randomSplit([3.0,1.0], 24) #3:1 
rf = RandomForestClassifier(labelCol="label", featuresCol="features", numTrees=32)
# GBTClassifier only supports binary classification 
#rf = GBTClassifier(labelCol="label", featuresCol="features")
pipeline = Pipeline(stages=[assembler,rf])
# Train model.  This also runs the indexers.
model = pipeline.fit(trainingData)

#Test Error 
predictions = model.transform(testData)
predictions.select("prediction", "label", "features").show(5)
#f1|weightedPrecision|weightedRecall|accuracy)
#f1 means weightedFMeasure ie  averages of all labels, ie fMeasure(category, beta) * count.toDouble / labelCount
evaluator = MulticlassClassificationEvaluator(labelCol="label", predictionCol="prediction", metricName="f1")
f1 = evaluator.evaluate(predictions)
print("Test f1:", f1)

#Training Error 
predictions = model.transform(trainingData)
f1 = evaluator.evaluate(predictions)
print(f"train f1: {f1}")

#OwnData 
from PIL import Image

#color image to greyscale (mode 'L'),
im = Image.open("data/4.jpg").convert('L')
#Image.thumbnail resizes to the largest size that preserves the aspect ratio
im = im.resize( (8,8), Image.ANTIALIAS ) #Mutate, wxh , we need 64 columns  

data = np.asarray(im)
#invert such that 0 becomes 255 
data = 255-data 
#im.show()
plt.imshow(data, cmap=plt.cm.gray_r, interpolation='nearest')
plt.title("We are predicting this image")
plt.show()
one_row=data.ravel()
one_row.shape  #(64, )
   
pdfT = pd.DataFrame(one_row[None,:] ,columns=feature_names)
dfT = spark.createDataFrame(pdfT)
model.transform(dfT).select("prediction").show()