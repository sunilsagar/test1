from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

from yellowbrick.classifier import *


#taiwan credits defaults uci data
#last column default- Yes=1, no=0
#Column2: Sex (1 = male; 2 = female).
#Column3: Education(0-6) (1 = graduate school; 2 = university; 3 = high school; 4 = others).
#Column4: Marital status(0-3) (1 = married; 2 = single; 3 = others)
#convert to OnhotEncoding 
df = pd.read_csv("data/credit.csv")
oh = OneHotEncoder()
y = df.iloc[:, -1] #last column is Default 

#from here 
X_one = df.iloc[:, [1,2,3]]   #onehotencoding is required for Sex, Edu, Marital 
X_other = pd.concat([df['limit'], df.iloc[:,4:-1]]   ,axis=1) #columwise 

X = pd.concat([pd.DataFrame(oh.fit_transform(X_one).toarray()),X_other], axis=1)

model = GradientBoostingClassifier()

#OR with pipeline 
#def process(arr):
#    X_one = arr[:, 1:4]
#    X_other = np.concatenate([arr[:,0:1], arr[:,4:-1]]   , axis=1) #requires 2D
#    oh = OneHotEncoder()
#    X = np.concatenate([oh.fit_transform(X_one).toarray(),X_other], axis=1)
#    return X 
#
#ft = FunctionTransformer(process)
#X = ft.fit_transform(df.values)
#model = Pipeline([('ft', ft),('clf',RandomForestClassifier())])

X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=0) 


fig, (ax1,ax2) = plt.subplots(1,2)
# Instantiate the classification model and visualizer
visualizer = ConfusionMatrix( model, ax=ax1, classes=['Good', 'Bad'] )
visualizer.fit(X_train, y_train)
visualizer.score(X_test, y_test)
visualizer.finalize()
visualizer = ROCAUC(model, ax=ax2, classes=['Good', 'Bad'])
visualizer.fit(X_train, y_train)
visualizer.score(X_test, y_test)
visualizer.show()