from __future__ import print_function, division
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
from pyspark import *                   #SparkContext,RDD,Broadcast,Accumulator,SparkConf,SparkFiles,StorageLevel,TaskContext

from pyspark.sql import *               #SparkSession, DataFrame, Column, Row, GroupedData, DataFrameNaFunctions, DataFrameStatFunctions, Window
import pyspark.sql.functions as F
from pyspark.sql.types import * 

from pyspark.ml  import *               #Transformer, UnaryTransformer,Estimator,Model,Pipeline,PipelineModel
from pyspark.ml.feature import *        #Binarizer, BucketedRandomProjectionLSHE, BucketedRandomProjectionLSHModelE, Bucketizer, ChiSqSelectorE, ChiSqSelectorModelE, CountVectorizer, CountVectorizerModel, DCT, ElementwiseProduct, FeatureHasherE, HashingTF, IDF, IDFModel, ImputerE, ImputerModelE, IndexToString, MaxAbsScaler, MaxAbsScalerModel, MinHashLSHE, MinHashLSHModelE, MinMaxScaler, MinMaxScalerModel, NGram, Normalizer, OneHotEncoderD, OneHotEncoderEstimator, OneHotEncoderModel, PCA, PCAModel, PolynomialExpansion, QuantileDiscretizerE, RegexTokenizer, RFormulaE, RFormulaModelE, SQLTransformer, StandardScaler, StandardScalerModel, StopWordsRemover, StringIndexer, StringIndexerModel, Tokenizer, VectorAssembler, VectorIndexer, VectorIndexerModel, VectorSizeHintE, VectorSlicer, Word2Vec, Word2VecModel, , 
from pyspark.ml.classification import * #LinearSVCE, LinearSVCModelE, LogisticRegression, LogisticRegressionModel, LogisticRegressionSummaryE, LogisticRegressionTrainingSummaryE, BinaryLogisticRegressionSummaryE, BinaryLogisticRegressionTrainingSummaryE, DecisionTreeClassifier, DecisionTreeClassificationModel, GBTClassifier, GBTClassificationModel, RandomForestClassifier, RandomForestClassificationModel, NaiveBayes, NaiveBayesModel, MultilayerPerceptronClassifier, MultilayerPerceptronClassificationModel, OneVsRestE, OneVsRestModelE, , 
from pyspark.ml.clustering import *     #BisectingKMeans, BisectingKMeansModel, BisectingKMeansSummaryE, KMeans, KMeansModel, GaussianMixture, GaussianMixtureModel, GaussianMixtureSummaryE, LDA, LDAModel, LocalLDAModel, DistributedLDAModel, , 
from pyspark.ml.linalg import *         #Vector, DenseVector, SparseVector, Vectors, Matrix, DenseMatrix, SparseMatrix, Matrices, , 
from pyspark.ml.recommendation import * #ALS, ALSModel, , 
from pyspark.ml.regression import *     #AFTSurvivalRegressionE, AFTSurvivalRegressionModelE, DecisionTreeRegressor, DecisionTreeRegressionModel, GBTRegressor, GBTRegressionModel, GeneralizedLinearRegressionE, GeneralizedLinearRegressionModelE, GeneralizedLinearRegressionSummaryE, GeneralizedLinearRegressionTrainingSummaryE, IsotonicRegression, IsotonicRegressionModel, LinearRegression, LinearRegressionModel, LinearRegressionSummaryE, LinearRegressionTrainingSummaryE, RandomForestRegressor, RandomForestRegressionModel, , 
from pyspark.ml.stat import *           #moduleChiSquareTestE, CorrelationE, , 
from pyspark.ml.tuning import *         #ParamGridBuilder, CrossValidator, CrossValidatorModel, TrainValidationSplitE, TrainValidationSplitModelE, , 
from pyspark.ml.evaluation import *     #Evaluator, BinaryClassificationEvaluatorE, RegressionEvaluatorE, MulticlassClassificationEvaluatorE, ClusteringEvaluatorE, , 
from pyspark.ml.fpm import *            #FPGrowthE, FPGrowthModelE, , 
from pyspark.ml.util import *           #BaseReadWrite, DefaultParamsReadable, DefaultParamsReader, DefaultParamsWritable, DefaultParamsWriter, Identifiable, JavaMLReadable, JavaMLReader, JavaMLWritable, JavaMLWriter, JavaPredictionModel, MLReadable, MLReader, MLWritable, MLWriter, , , 

spark = SparkSession.builder.appName("basic").getOrCreate()

data = spark.read.format("csv").option("encoding", "ISO-8859-1").options(header=True, inferSchema=True).load("data/spam.csv")

#Any missing value 
#data.select(*[F.sum(F.col(c).isNull().cast("int")).alias(c) for c in data.columns]).show()
#df.select(df.columns.map(c => sum(col(c).isNull.cast("int")).alias(c)): _*).show

sentenceData = data.withColumnRenamed("v1", "raw_label").withColumnRenamed("v2", "sentence").select("raw_label", "sentence").na.drop() #drop any null or NA 

labelIndexer = StringIndexer(inputCol="raw_label", outputCol="label").fit(sentenceData)
labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel",
                               labels=labelIndexer.labels)

                     
#TFIDF 
tokenizer = Tokenizer(inputCol="sentence", outputCol="words")
#wordsData = tokenizer.transform(sentenceData)

#numFeatures - to restrict the size, comment and see the accuracy imporves 
hashingTF = HashingTF(inputCol="words", outputCol="rawFeatures", numFeatures=20)
#featurizedData = hashingTF.transform(wordsData)
# cv = CountVectorizer(inputCol="words", outputCol="rawFeatures")

idf = IDF(inputCol="rawFeatures", outputCol="features")
#idfModel = idf.fit(featurizedData)
#rescaledData = idfModel.transform(featurizedData)
#rescaledData.show()

# create the trainer and set its parameters
nb = NaiveBayes(smoothing=1.0, modelType="multinomial",featuresCol="features",labelCol='label')

#minmaxscaler =  MinMaxScaler(inputCol="features", outputCol="scaledFeatures")
#pca = PCA(k=2, inputCol="scaledFeatures", outputCol="pcaFeatures")

# Split the data into training and test sets (30% held out for testing)
(trainingData, testData) = sentenceData.randomSplit([0.7, 0.3])

# Chain indexers and forest in a Pipeline
pipeline = Pipeline(stages=[labelIndexer,tokenizer,hashingTF, idf, nb, labelConverter])

# Train model.  This also runs the indexers.
model = pipeline.fit(trainingData)

# Make predictions.
predictions = model.transform(testData)

# Select example rows to display.
predictions.select("predictedLabel", "raw_label", "prediction", "label", "features").show(5)
slp = predictions.withColumn("label", F.col("label").cast("int")).withColumn("prediction", F.col("prediction").cast("double")).select("label", "prediction")

# Select (prediction, true label) and compute test error
evaluator = MulticlassClassificationEvaluator(labelCol="label", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(slp)
print("Test accuracy = %g" % (accuracy,))