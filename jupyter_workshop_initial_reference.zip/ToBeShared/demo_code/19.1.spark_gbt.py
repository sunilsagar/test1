from __future__ import print_function, division
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 
from pyspark import *                   #SparkContext,RDD,Broadcast,Accumulator,SparkConf,SparkFiles,StorageLevel,TaskContext

from pyspark.sql import *               #SparkSession, DataFrame, Column, Row, GroupedData, DataFrameNaFunctions, DataFrameStatFunctions, Window
import pyspark.sql.functions as F
from pyspark.sql.types import * 

from pyspark.ml  import *               #Transformer, UnaryTransformer,Estimator,Model,Pipeline,PipelineModel
from pyspark.ml.feature import *        #Binarizer, BucketedRandomProjectionLSHE, BucketedRandomProjectionLSHModelE, Bucketizer, ChiSqSelectorE, ChiSqSelectorModelE, CountVectorizer, CountVectorizerModel, DCT, ElementwiseProduct, FeatureHasherE, HashingTF, IDF, IDFModel, ImputerE, ImputerModelE, IndexToString, MaxAbsScaler, MaxAbsScalerModel, MinHashLSHE, MinHashLSHModelE, MinMaxScaler, MinMaxScalerModel, NGram, Normalizer, OneHotEncoderD, OneHotEncoderEstimator, OneHotEncoderModel, PCA, PCAModel, PolynomialExpansion, QuantileDiscretizerE, RegexTokenizer, RFormulaE, RFormulaModelE, SQLTransformer, StandardScaler, StandardScalerModel, StopWordsRemover, StringIndexer, StringIndexerModel, Tokenizer, VectorAssembler, VectorIndexer, VectorIndexerModel, VectorSizeHintE, VectorSlicer, Word2Vec, Word2VecModel, , 
from pyspark.ml.classification import * #LinearSVCE, LinearSVCModelE, LogisticRegression, LogisticRegressionModel, LogisticRegressionSummaryE, LogisticRegressionTrainingSummaryE, BinaryLogisticRegressionSummaryE, BinaryLogisticRegressionTrainingSummaryE, DecisionTreeClassifier, DecisionTreeClassificationModel, GBTClassifier, GBTClassificationModel, RandomForestClassifier, RandomForestClassificationModel, NaiveBayes, NaiveBayesModel, MultilayerPerceptronClassifier, MultilayerPerceptronClassificationModel, OneVsRestE, OneVsRestModelE, , 
from pyspark.ml.clustering import *     #BisectingKMeans, BisectingKMeansModel, BisectingKMeansSummaryE, KMeans, KMeansModel, GaussianMixture, GaussianMixtureModel, GaussianMixtureSummaryE, LDA, LDAModel, LocalLDAModel, DistributedLDAModel, , 
from pyspark.ml.linalg import *         #Vector, DenseVector, SparseVector, Vectors, Matrix, DenseMatrix, SparseMatrix, Matrices, , 
from pyspark.ml.recommendation import * #ALS, ALSModel, , 
from pyspark.ml.regression import *     #AFTSurvivalRegressionE, AFTSurvivalRegressionModelE, DecisionTreeRegressor, DecisionTreeRegressionModel, GBTRegressor, GBTRegressionModel, GeneralizedLinearRegressionE, GeneralizedLinearRegressionModelE, GeneralizedLinearRegressionSummaryE, GeneralizedLinearRegressionTrainingSummaryE, IsotonicRegression, IsotonicRegressionModel, LinearRegression, LinearRegressionModel, LinearRegressionSummaryE, LinearRegressionTrainingSummaryE, RandomForestRegressor, RandomForestRegressionModel, , 
from pyspark.ml.stat import *           #moduleChiSquareTestE, CorrelationE, , 
from pyspark.ml.tuning import *         #ParamGridBuilder, CrossValidator, CrossValidatorModel, TrainValidationSplitE, TrainValidationSplitModelE, , 
from pyspark.ml.evaluation import *     #Evaluator, BinaryClassificationEvaluatorE, RegressionEvaluatorE, MulticlassClassificationEvaluatorE, ClusteringEvaluatorE, , 
from pyspark.ml.fpm import *            #FPGrowthE, FPGrowthModelE, , 
from pyspark.ml.util import *           #BaseReadWrite, DefaultParamsReadable, DefaultParamsReader, DefaultParamsWritable, DefaultParamsWriter, Identifiable, JavaMLReadable, JavaMLReader, JavaMLWritable, JavaMLWriter, JavaPredictionModel, MLReadable, MLReader, MLWritable, MLWriter, , , 


spark = SparkSession.builder.appName("basic").getOrCreate()
# from sklearn import datasets
# # Load data
# boston = datasets.load_boston() #boston.data=np, boston.target, boston.feature_names
# pdf = pd.DataFrame(boston.data, columns=boston.feature_names)
# pdf['MEDV'] = boston.target
# data = spark.createDataFrame(pdf)

#read 
data = spark.read.format("csv").option("inferSchema", "true")\
            .option("header", "true").load("data/boston.csv")
            
feature_names = data.columns[:-1]          
trainingData, testData = data.randomSplit([3.0,1.0], 24)

# If data has categorical features 
#Automatically identify categorical features, and index them.
# Set maxCategories so features with > 4 distinct values are treated as continuous.
#In our case all are continuous, hence not needed 
#note this is a transformer, hence call fit
#featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)
#gbt = GBTRegressor(featuresCol="indexedFeatures",labelCol='MEDV', predictionCol='prediction', maxIter=10)
#pipeline = Pipeline(stages=[featureIndexer, gbt])

assembler = VectorAssembler().setInputCols(feature_names).setOutputCol("features")
scaler = StandardScaler(inputCol="features", outputCol="scaledFeatures")
gbt = GBTRegressor(featuresCol="scaledFeatures",labelCol='medv', predictionCol='prediction', maxIter=10)
#Pipeline(stages=[Transformer1, Transformer2,...,Estimator1,Estimator2,...])
#Transformer means which has .transform method, Estimator is one having .fit and .transform 
pipeline = Pipeline(stages=[assembler, scaler, gbt])
model = pipeline.fit(trainingData)


#Training error 
predictions = model.transform(trainingData)
predictions.select("prediction", "medv", "features").show(5)
# rmse - root mean squared error (default) mse - mean squared error r2 - r^2 metric mae - mean absolute error
evaluator = RegressionEvaluator(labelCol="medv", predictionCol="prediction", metricName="r2")
r2_train = evaluator.evaluate(predictions) #not so good 
# Test Error 
predictions = model.transform(testData)
r2_test = evaluator.evaluate(predictions) 
print("Train error:", r2_train, "Test error:", r2_test)

print("Tune parameter ") #- Advantage of ML 
#GBTRegressor(featuresCol='features', labelCol='label', predictionCol='prediction', maxDepth=5, maxBins=32, minInstancesPerNode=1, minInfoGain=0.0, maxMemoryInMB=256, cacheNodeIds=False, subsamplingRate=1.0, checkpointInterval=10, lossType='squared', maxIter=20, stepSize=0.1, seed=None, impurity='variance')
gbt.explainParams() #check all parameters 
paramGrid = ParamGridBuilder()\
    .addGrid(gbt.maxDepth, [5,3,7]) \
    .addGrid(gbt.maxIter, [10,20,25])\
    .build()

#CrossValidator - expensive, but reliable for small data set, 
# requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
tvs = TrainValidationSplit(estimator=pipeline,
                           estimatorParamMaps=paramGrid,
                           evaluator=RegressionEvaluator(labelCol="medv", predictionCol="prediction", metricName="r2"),
                           # 80% of the data will be used for training, 20% for validation.
                           trainRatio=0.8)

# Run TrainValidationSplit, and choose the best set of parameters.
model = tvs.fit(trainingData)

#Check now 
#Training error 
predictions = model.transform(trainingData)
predictions.select("prediction", "medv", "features").show(5)
# rmse - root mean squared error (default) mse - mean squared error r2 - r^2 metric mae - mean absolute error
evaluator = RegressionEvaluator(labelCol="medv", predictionCol="prediction", metricName="r2")
r2_train = evaluator.evaluate(predictions) 
# Test Error 
predictions = model.transform(testData)
r2_test = evaluator.evaluate(predictions) 
print("Train error:", r2_train, "Test error:", r2_test)

model.getEstimatorParamMaps() #params for all combination 
model.validationMetrics #metric for each combination 
np.argmax(model.validationMetrics)
print("best model :",
model.getEstimatorParamMaps()[np.argmax(model.validationMetrics)] )
