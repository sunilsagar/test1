from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt

import io,os
import requests
import zipfile

print("""
The autocorrelation of a time series can inform us about repeating patterns or serial correlation. 
The latter refers to the correlation between the signal at a given time and at a later time. 
The analysis of the autocorrelation can thereby inform us about the timescale of the fluctuations. 

Here, we use this tool to analyze the evolution of baby names in the US, 
based on data provided by the United States Social Security Administration.
""")

url = ("https://raw.githubusercontent.com/ndas1971/Misc/master/babies.zip")
r = io.BytesIO(requests.get(url).content)
zipfile.ZipFile(r).extractall('babies')

#yob1903.txt
#yob1904.txt
#...
#yob2014.txt
#yob2015.txt
#yob2016.txt

#read the data with pandas
files = [file for file in os.listdir('babies')  if file.startswith('yob')]

years = np.array(sorted([int(file[3:7])   for file in files]))

data = {year: pd.read_csv('babies/yob%d.txt' % year,
                    index_col=0, header=None,
                    names=['First name',
                           'Gender',
                           'Number'])
        for year in years}

print(data[2016].head())

#retrieve the frequencies of baby names as a function of the name, gender, and birth year:
def get_value(name, gender, year):
    """Return the number of babies born a given year,
    with a given gender and a given name."""
    dy = data[year]
    try:
        return dy[dy['Gender'] == gender]['Number'][name]
    except KeyError:
        return 0

def get_evolution(name, gender):
    """Return the evolution of a baby name over
    the years."""
    return np.array([get_value(name, gender, year) for year in years])

#define a function that computes the autocorrelation of a signal. 
#This function is essentially based on NumPy's correlate() function.

def autocorr(x):
    result = np.correlate(x, x, mode='full')
    return result[result.size // 2:]

#displays the evolution of a baby name as well as its (normalized) autocorrelation:

def autocorr_name(name, gender, color, axes=None):
    x = get_evolution(name, gender)
    z = autocorr(x)

    # Evolution of the name.
    axes[0].plot(years, x, '-o' + color,
                 label=name)
    axes[0].set_title("Baby names")
    axes[0].legend()

    # Autocorrelation.
    axes[1].plot(z / float(z.max()),
                 '-' + color, label=name)
    axes[1].legend()
    axes[1].set_title("Autocorrelation")

print("""
look at two female names: Olivia vs Maria

The autocorrelation quantifies the average similarity between the signal
and a shifted version of the same signal, as a function of the delay between the two. 
In other words, the autocorrelation can give us information about repeating patterns 
as well as the timescale of the signal's fluctuations. 
The faster the autocorrelation decays to zero, the faster the signal varies.

The autocorrelation of Olivia is decaying much faster than Maria's. 
This is mainly because of the steep increase of the name Olivia at the end of the twentieth century. 
By contrast, the name Maria is varying more slowly globally, 
and its autocorrelation is decaying slower.
""")
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
autocorr_name('Olivia', 'F', 'k', axes=axes)
autocorr_name('Maria', 'F', 'y', axes=axes)