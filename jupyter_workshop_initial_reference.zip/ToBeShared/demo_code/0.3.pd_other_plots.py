import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("""
Other Plots 
https://pandas.pydata.org/pandas-docs/stable/visualization.html
""")

##scatter_matrix 
from pandas.plotting import scatter_matrix
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
scatter_matrix(df, alpha=0.2, figsize=(6, 6), diagonal='kde', label="SCatter Matrix")
plt.suptitle('scatter-matrix')
plt.show()

#DataFrame.plot.density([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.
#DataFrame.plot.kde([bw_method, ind]) 	Generate Kernel Density Estimate plot using Gaussian kernels.

#only density plot 
df.a.plot.kde()
plt.title("only density plot")
plt.show()


print("""
lagplot -Lag plots are used to check if a data set or time series is random. 
Random data should not exhibit any structure in the lag plot. 
Non-random structure implies that the underlying data are not random.
""")
from pandas.plotting import lag_plot
lag_plot(df.a)
plt.title("Lag plot")
plt.show()

print("""
Autocorrelation plots are often used for checking randomness in time series
If time series is random, such autocorrelations 
should be near zero for any and all time-lag separations
""")

from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.a)
plt.title("Autocorrelation plot")
plt.show()

print("""
Bootstrap plots are used to visually assess the uncertainty of a statistic, 
such as mean, median, midrange, etc. 
A random subset of a specified size is selected from a data set, 
the statistic in question is computed for this subset 
and the process is repeated a specified number of times. 
Resulting plots and histograms are what constitutes the bootstrap plot.
""")
from pandas.plotting import bootstrap_plot
bootstrap_plot(df.a, size=50, samples=500, color='grey')
plt.suptitle("Bootstrap plot")
plt.show()


iris = pd.read_csv('data/iris.csv')

#histogram 
#alpha = transparent
#superimposed 
iris.iloc[:, 0:4].plot.hist( alpha=0.5, bins=50)
plt.title("histogram-superimposed")
plt.show()

#seperate 
iris.iloc[:, 0:4].hist( color='k', alpha=0.5, bins=50)
plt.suptitle("histogram-seperate")
plt.show()

## Scatter plot 
iris.iloc[:, 0:4].plot.scatter(x='PetalLength', y='PetalWidth')
#iris.iloc[:, 0:4].plot.line(x='PetalLength', y='PetalWidth')
plt.title("Scatter plot")
plt.show()


## bar plot 
#single row 
iris.iloc[5, 0:4].plot.bar(); plt.axhline(0, color='k'); plt.axvline(0, color='k')
plt.title("bar plot -single row ")
plt.show()
#many row s
iris.iloc[50:60,0:4].plot.bar()
plt.title("bar plot - many rows")
plt.show()
iris.iloc[50:60,0:4].plot.bar(stacked=True)
plt.title("bar plot - stacked")
plt.show()
iris.iloc[50:60,0:4].plot.barh(stacked=True)
plt.title("bar plot - horizontal stacked ")
plt.show()
#pie single row 
iris.iloc[50,0:4].plot.pie(subplots=True)
plt.title("bar plot - pie ")
plt.show()

#DataFrame.plot.area([x, y]) 	Draw a stacked area plot.
df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
df.plot.area()
plt.title("stacked area plot")
plt.show()

#DataFrame.plot.hexbin(x, y[, C, …]) 	Generate a hexagonal binning plot.
print("""
Useful alternative to scatter plots 
if data are too dense to plot each point individually.
Hexagonal binning plots density, rather than points. 
Points are binned into gridded hexagons 
and distribution (the number of points per hexagon) is displayed 
using either the color or the area of the hexagons
More prominent color means more data points 
OR bigger the area, more data point 

gridsize: Number of bins
""")
df = pd.DataFrame(np.random.randn(1000, 2), columns=['a', 'b'])
df['b'] = df['b'] + np.arange(1000)
df.plot.hexbin(x='a', y='b', gridsize=25)
plt.title("hexagonal binning plot")
plt.show()


